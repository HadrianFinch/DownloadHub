ls

echo foooooooo